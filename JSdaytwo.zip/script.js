let billamount = 200;
let tip = .2;


function calculateTIp(billamount, tip) {
    return billamount * tip;

}

let resulttip= calculateTIp (billamount, tip);

console.log(resulttip.toFixed (2));


function getBillTotal (billamount, resulttip){
    return billamount + resulttip;
}

let billtotal= getBillTotal (billamount, resulttip)

console.log(billtotal.toFixed(2))